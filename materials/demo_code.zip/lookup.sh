grep '[aoeiu][aoeiu][aoeiu][aoeiu]' /usr/share/dict/words
# try the command and then ask AI how to simplify this expression
