#!/usr/bin/perl

print `man $ARGV[0] | head\n`

