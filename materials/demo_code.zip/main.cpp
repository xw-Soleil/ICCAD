#include <iostream>

using namespace std;

int main()
{
	cout << "flkfdsf";
	return 1;
}
