#include <stdio.h>
extern void foo();
main()
{
	printf("calling function foo…\n");
	foo();
}
