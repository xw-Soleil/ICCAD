#include <stdio.h>

main()
{
	char p[100];
	scanf("%s",p);
	printf("ABCDEF\n");
	printf("%s", p);
}
